﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.IO;
using ExcelLibrary.SpreadSheet;
using OfficeOpenXml;

namespace WSIC2010.Util
{
    public class ExcelHelper
    {
        public static DataSet CreateDataSet(String filePath)
        {
            DataSet ds = new DataSet();
            if (filePath.ToUpper().EndsWith(".XLS"))
            {
                Workbook workbook = Workbook.Load(filePath);
                foreach (Worksheet ws in workbook.Worksheets)
                {
                    DataTable dt = PopulateDataTable(ws);
                    ds.Tables.Add(dt);
                }
            }
            else if (filePath.ToUpper().EndsWith(".XLSX"))
            {
                if (File.Exists(filePath))
                    throw new FileNotFoundException("Archivo No encontrado");

                var newFile = new FileInfo(filePath);
 
                using (var package = new ExcelPackage(newFile))
                {
                    ExcelWorkbook workbook = package.Workbook;
                    foreach (ExcelWorksheet ws in workbook.Worksheets)
                    {
                        //DataTable dt = PopulateDataTable(ws);
                        //ds.Tables.Add(dt);
                    }
                }
            }
            
            return ds;
        }

        private static DataTable PopulateDataTable(Worksheet ws)
        {
            CellCollection Cells = ws.Cells;

            // Creates DataTable from a Worksheet
            // All values will be treated as Strings
            DataTable dt = new DataTable(ws.Name);

            // Extract columns
            for (int i = 0; i <= Cells.LastColIndex; i++)
                dt.Columns.Add(ExcelUtil.GetExcelColumnName(i + 1).ToString(), typeof(String));

            // Extract data
            for (int currentRowIndex = 0; currentRowIndex <= Cells.LastRowIndex; currentRowIndex++)
            {
                DataRow dr = dt.NewRow();
                for (int currentColumnIndex = 0; currentColumnIndex <= Cells.LastColIndex; currentColumnIndex++)
                    dr[currentColumnIndex] = Cells[currentRowIndex, currentColumnIndex].StringValue;
                dt.Rows.Add(dr);
            }

            return dt;
        }

    }
}